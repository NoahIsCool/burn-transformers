//! Deterministic cached beam search for encoder-decoder language models.
//!
//! Beam search approximates
//! `argmax_y sum_t log p(y_t | y_<t, x)` by retaining the `K` greatest
//! unfinished prefixes after every decoder step. Finished hypotheses are kept
//! separately and ranked by
//! `score(y) = log p(y | x) / |y|^length_penalty`, where `|y|` counts only
//! tokens generated after the caller-supplied decoder prompt. This definition
//! makes the length convention explicit and avoids silently treating T5's
//! decoder-start token as model output.
//!
//! Encoder computation runs once. Its output and the external decoder cache are
//! expanded to a fixed `[source_batch * beams]` batch. At each later step,
//! [`DecodeState::reorder`] gathers or duplicates parent rows before selected
//! tokens enter [`Seq2SeqLanguageModel::decode`]. Finished source rows remain in
//! that rectangle as false-masked PAD no-ops, preserving other rows' progress
//! without mutating their cache lengths.
//!
//! This portable reference coordinator transfers log probabilities to the host
//! to perform an exact stable ordering over every beam-vocabulary pair. Model
//! tensors and caches stay on the backend. Backend-specific fused top-k search
//! can implement the same public semantics later without changing model code.

use burn::tensor::{
    ElementConversion, Int, Tensor, TensorData, activation::log_softmax, backend::Backend,
};
use serde::{Deserialize, Serialize};

use super::causal::host_float_data_f64;

use crate::{
    CausalLmInput, DecodeInput, DecodeState, EncoderOutput, Error, FinishReason, ForwardOptions,
    LogitsSelection, Result, Seq2SeqLanguageModel, TokenMask,
    architecture::{bool_tensor_from_values, select_bool_tensor},
    cache::CacheConfig,
};

/// Deterministic beam width, termination, and ranking controls.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct BeamSearchConfig {
    /// Maximum number of tokens generated after the decoder prompt.
    pub max_new_tokens: usize,
    /// Number of live decoder prefixes retained for each source row.
    pub num_beams: usize,
    /// Number of ranked hypotheses returned for each source row.
    pub num_return_sequences: usize,
    /// Exponent in `cumulative_log_probability / generated_length^penalty`.
    pub length_penalty: f64,
    /// Stop a source row as soon as `num_beams` finished hypotheses exist.
    ///
    /// Following Transformers 5.2 eager semantics, only finished candidates
    /// ranked within the current top `num_beams` may enter that pool; the rest
    /// of the wider candidate frontier exists solely to find live successors.
    /// When false, search continues to the configured length bound so an
    /// unfinished prefix may still overtake an early EOS after length
    /// normalization.
    pub early_stopping: bool,
    /// Token IDs that finish a hypothesis after being appended.
    pub eos_token_ids: Vec<u32>,
    /// Token supplied with a false mask for inactive slots in rectangular calls.
    pub pad_token_id: u32,
}

impl Default for BeamSearchConfig {
    /// Returns conventional four-beam, single-result search controls.
    fn default() -> Self {
        Self {
            max_new_tokens: 64,
            num_beams: 4,
            num_return_sequences: 1,
            length_penalty: 1.0,
            early_stopping: false,
            eos_token_ids: Vec::new(),
            pad_token_id: 0,
        }
    }
}

impl BeamSearchConfig {
    /// Validates beam geometry and token IDs against a vocabulary.
    pub fn validate(&self, vocabulary_size: usize) -> Result<()> {
        if vocabulary_size == 0 {
            return Err(Error::Generation(
                "beam-search vocabulary_size must be greater than zero".into(),
            ));
        }
        if self.max_new_tokens == 0 {
            return Err(Error::Generation(
                "beam-search max_new_tokens must be greater than zero".into(),
            ));
        }
        if self.num_beams == 0 {
            return Err(Error::Generation(
                "beam-search num_beams must be greater than zero".into(),
            ));
        }
        if self.num_beams > vocabulary_size {
            return Err(Error::Generation(format!(
                "beam-search num_beams {} exceeds vocabulary size {vocabulary_size}",
                self.num_beams
            )));
        }
        if self.num_return_sequences == 0 || self.num_return_sequences > self.num_beams {
            return Err(Error::Generation(format!(
                "beam-search num_return_sequences must be in 1..={}, found {}",
                self.num_beams, self.num_return_sequences
            )));
        }
        if !self.length_penalty.is_finite() {
            return Err(Error::Generation(format!(
                "beam-search length_penalty must be finite, found {}",
                self.length_penalty
            )));
        }
        let maximum_normalizer = (self.max_new_tokens as f64).powf(self.length_penalty);
        if !maximum_normalizer.is_finite() || maximum_normalizer == 0.0 {
            return Err(Error::Generation(format!(
                "beam-search length_penalty {} is not numerically representable through length {}",
                self.length_penalty, self.max_new_tokens
            )));
        }
        if u32::try_from(vocabulary_size - 1).is_err() {
            return Err(Error::Generation(format!(
                "beam-search vocabulary size {vocabulary_size} exceeds the u32 token-ID domain"
            )));
        }
        if self.pad_token_id as usize >= vocabulary_size {
            return Err(Error::Generation(format!(
                "beam-search PAD token {} is outside vocabulary size {vocabulary_size}",
                self.pad_token_id
            )));
        }
        for &token in &self.eos_token_ids {
            if token as usize >= vocabulary_size {
                return Err(Error::Generation(format!(
                    "beam-search EOS token {token} is outside vocabulary size {vocabulary_size}"
                )));
            }
        }
        Ok(())
    }
}

/// Complete tensors and policies for one encoder-decoder beam search.
#[derive(Clone, Debug)]
pub struct Seq2SeqBeamSearchRequest<B: Backend> {
    /// Source tokens encoded exactly once before beam expansion.
    pub source: CausalLmInput<B>,
    /// Initial decoder prefix, commonly T5's one-token decoder start ID.
    pub decoder_prompt: CausalLmInput<B>,
    /// Fixed-size cache for `source_batch * num_beams` decoder rows.
    pub cache: CacheConfig,
    /// Beam width, length normalization, and stopping controls.
    pub search: BeamSearchConfig,
    /// Number of output categories in the decoder language head.
    pub vocabulary_size: usize,
}

/// One returned decoder hypothesis and its probability accounting.
#[derive(Clone, Debug, PartialEq)]
pub struct BeamSearchSequence {
    /// Count of valid tokens in the caller-supplied decoder prompt.
    pub decoder_prompt_length: usize,
    /// Generated token IDs, including a terminal EOS when selected.
    pub token_ids: Vec<u32>,
    /// Conditional log probability for each generated token.
    pub log_probabilities: Vec<f64>,
    /// Sum of all entries in [`Self::log_probabilities`].
    pub cumulative_log_probability: f64,
    /// Length-normalized score used to rank returned hypotheses.
    pub score: f64,
    /// Condition that finalized this hypothesis.
    pub finish_reason: FinishReason,
}

/// Ranked beam-search results grouped in original source-batch order.
#[derive(Clone, Debug, PartialEq)]
pub struct Seq2SeqBeamSearchOutput {
    /// Per-source hypotheses ordered from greatest to least beam score.
    pub sequences: Vec<Vec<BeamSearchSequence>>,
}

/// Runs deterministic cached beam search for any encoder-decoder architecture.
///
/// Equal candidate scores are ordered by parent beam and then token ID. Equal
/// finished scores are ordered by cumulative score, lexicographic token IDs,
/// and finally creation order. These rules make results reproducible even when
/// a backend's vocabulary sort does not define ties.
pub fn generate_seq2seq_beam_search<B, M>(
    model: &M,
    request: Seq2SeqBeamSearchRequest<B>,
) -> Result<Seq2SeqBeamSearchOutput>
where
    B: Backend,
    M: Seq2SeqLanguageModel<B>,
{
    let prepared = PreparedRequest::new(&request)?;
    let device = request.source.token_ids.device();
    let options = ForwardOptions {
        logits: LogitsSelection::Last,
        ..ForwardOptions::default()
    };

    let encoded = model.encode(request.source, &options)?;
    validate_encoder_batch(&encoded, prepared.source_batch)?;
    let expansion = beam_expansion_indices(prepared.source_batch, request.search.num_beams)?;
    let mut encoder = select_encoder(encoded, &expansion)?;
    let decoder_prompt = select_input(request.decoder_prompt, &expansion)?;
    let mut state = model.new_decode_state(request.cache, prepared.expanded_batch, &device)?;
    let prefill = model.prefill_decoder(&encoder, decoder_prompt, &mut state, &options)?;
    encoder = prefill.encoder;
    validate_encoder_batch(&encoder, prepared.expanded_batch)?;
    let mut logits = extract_last_logits(
        prefill.decoder.logits,
        prepared.expanded_batch,
        request.vocabulary_size,
    )?;

    let mut active = initial_beams(&prepared)?;
    let mut completed = empty_completed(prepared.source_batch)?;
    let mut done = vec![false; prepared.source_batch];
    let mut ordinal = 0_usize;

    for step in 0..request.search.max_new_tokens {
        let active_rows = active
            .iter()
            .enumerate()
            .map(|(row, beam)| {
                let source = row / request.search.num_beams;
                beam.is_some() && !done[source]
            })
            .collect::<Vec<_>>();
        let probabilities = host_log_probabilities(
            logits,
            &active_rows,
            prepared.expanded_batch,
            request.vocabulary_size,
        )?;
        let at_length_limit = step + 1 == request.search.max_new_tokens;
        let mut next_active = vec![None; prepared.expanded_batch];
        let mut parent_indices = (0..prepared.expanded_batch).collect::<Vec<_>>();
        let mut next_tokens = vec![i64::from(request.search.pad_token_id); prepared.expanded_batch];
        let mut next_valid = vec![false; prepared.expanded_batch];
        let mut decode_positions = prepared
            .has_explicit_decoder_positions
            .then(|| vec![0_i64; prepared.expanded_batch]);

        for (source, source_done) in done.iter_mut().enumerate() {
            if *source_done {
                continue;
            }
            let candidates = candidates_for_source(
                source,
                request.search.num_beams,
                request.vocabulary_size,
                &active,
                &probabilities,
            )?;
            if candidates.is_empty() {
                return Err(Error::Generation(format!(
                    "beam-search source row {source} has no finite candidate"
                )));
            }

            let mut selected = Vec::with_capacity(request.search.num_beams);
            let frontier = candidate_frontier_size(
                request.search.num_beams,
                request.search.eos_token_ids.len(),
                candidates.len(),
            )?;
            for (candidate_rank, candidate) in candidates.into_iter().take(frontier).enumerate() {
                let is_eos = request.search.eos_token_ids.contains(&candidate.token_id);
                if is_eos || at_length_limit {
                    // Transformers 5.2 masks finished candidates below the
                    // current beam width. Those extra frontier rows are only
                    // backups for selecting enough non-finished successors.
                    if candidate_rank >= request.search.num_beams {
                        continue;
                    }
                    let reason = if is_eos {
                        FinishReason::EndOfSequence {
                            token_id: candidate.token_id,
                        }
                    } else {
                        FinishReason::Length
                    };
                    let hypothesis = extend_candidate(&active, &candidate, Some(reason), ordinal)?;
                    ordinal = ordinal.checked_add(1).ok_or_else(|| {
                        Error::Generation("beam-search hypothesis ordinal overflow".into())
                    })?;
                    completed
                        .get_mut(source)
                        .ok_or_else(|| {
                            Error::Generation("completed beam batch became ragged".into())
                        })?
                        .push(hypothesis);
                } else if selected.len() < request.search.num_beams {
                    selected.push(candidate);
                }
            }
            rank_and_prune(
                completed.get_mut(source).ok_or_else(|| {
                    Error::Generation("completed beam batch became ragged".into())
                })?,
                request.search.num_beams,
                request.search.length_penalty,
            );

            if at_length_limit
                || (request.search.early_stopping
                    && completed
                        .get(source)
                        .ok_or_else(|| {
                            Error::Generation("completed beam batch became ragged".into())
                        })?
                        .len()
                        >= request.search.num_beams)
                || selected.is_empty()
            {
                *source_done = true;
                continue;
            }

            for (slot, candidate) in selected.into_iter().enumerate() {
                let destination = source
                    .checked_mul(request.search.num_beams)
                    .and_then(|offset| offset.checked_add(slot))
                    .ok_or_else(|| Error::Generation("beam destination index overflow".into()))?;
                let parent = active
                    .get(candidate.parent_global)
                    .and_then(Option::as_ref)
                    .ok_or_else(|| Error::Generation("selected beam parent disappeared".into()))?;
                if let Some(positions) = &mut decode_positions {
                    positions[destination] = parent.next_position.ok_or_else(|| {
                        Error::Generation("explicit beam position disappeared".into())
                    })?;
                }
                parent_indices[destination] = candidate.parent_global;
                next_tokens[destination] = i64::from(candidate.token_id);
                next_valid[destination] = true;
                next_active[destination] =
                    Some(extend_candidate(&active, &candidate, None, ordinal)?);
                ordinal = ordinal.checked_add(1).ok_or_else(|| {
                    Error::Generation("beam-search hypothesis ordinal overflow".into())
                })?;
            }
        }

        if done.iter().all(|finished| *finished) {
            break;
        }

        state.reorder(&parent_indices)?;
        encoder = select_encoder(encoder, &parent_indices)?;
        let token_ids = Tensor::<B, 2, Int>::from_data(
            TensorData::new(next_tokens, [prepared.expanded_batch, 1]),
            &device,
        );
        let valid = bool_tensor_from_values(next_valid, [prepared.expanded_batch, 1], &device);
        let position_ids = decode_positions.map(|positions| {
            Tensor::<B, 2, Int>::from_data(
                TensorData::new(positions, [prepared.expanded_batch, 1]),
                &device,
            )
        });
        active = next_active;
        let decoded = model.decode(
            &encoder,
            DecodeInput {
                token_ids,
                position_ids,
                token_mask: Some(TokenMask::new(valid)),
            },
            &mut state,
            &options,
        )?;
        encoder = decoded.encoder;
        validate_encoder_batch(&encoder, prepared.expanded_batch)?;
        logits = extract_last_logits(
            decoded.decoder.logits,
            prepared.expanded_batch,
            request.vocabulary_size,
        )?;
    }

    finish_output(completed, &prepared.decoder_prompt_lengths, &request.search)
}

/// Validated dimensions and position metadata derived before model mutation.
struct PreparedRequest {
    source_batch: usize,
    expanded_batch: usize,
    decoder_prompt_lengths: Vec<usize>,
    initial_next_positions: Option<Vec<i64>>,
    has_explicit_decoder_positions: bool,
}

impl PreparedRequest {
    /// Checks public request geometry and derives initial per-source beam state.
    fn new<B: Backend>(request: &Seq2SeqBeamSearchRequest<B>) -> Result<Self> {
        request.search.validate(request.vocabulary_size)?;
        let [source_batch, source_sequence] = request.source.token_ids.dims();
        let [decoder_batch, decoder_sequence] = request.decoder_prompt.token_ids.dims();
        if source_batch == 0 || source_sequence == 0 {
            return Err(Error::shape(
                "beam_search.source",
                "non-empty [batch, sequence]",
                format!("[{source_batch}, {source_sequence}]"),
            ));
        }
        if decoder_batch != source_batch || decoder_sequence == 0 {
            return Err(Error::shape(
                "beam_search.decoder_prompt",
                format!("[{source_batch}, nonzero_sequence]"),
                format!("[{decoder_batch}, {decoder_sequence}]"),
            ));
        }
        validate_input_metadata(&request.source, source_batch, source_sequence, "source")?;
        validate_input_metadata(
            &request.decoder_prompt,
            decoder_batch,
            decoder_sequence,
            "decoder_prompt",
        )?;
        let decoder_valid = mask_values(
            request.decoder_prompt.token_mask.as_ref(),
            decoder_batch,
            decoder_sequence,
            "decoder prompt mask",
        )?;
        let decoder_prompt_lengths = nonempty_row_lengths(
            &decoder_valid,
            decoder_batch,
            decoder_sequence,
            "decoder prompt",
        )?;
        let expanded_batch = source_batch
            .checked_mul(request.search.num_beams)
            .ok_or_else(|| Error::Generation("expanded beam batch overflows usize".into()))?;
        if request.cache.sequence_count() != expanded_batch {
            return Err(Error::Generation(format!(
                "beam-search cache tracks {} rows, expected source batch {source_batch} * {} beams = {expanded_batch}",
                request.cache.sequence_count(),
                request.search.num_beams
            )));
        }
        let maximum_prompt = decoder_prompt_lengths
            .iter()
            .copied()
            .max()
            .ok_or_else(|| {
                Error::Generation("decoder prompt lengths unexpectedly became empty".into())
            })?;
        let required_capacity = maximum_prompt
            .checked_add(request.search.max_new_tokens)
            .ok_or_else(|| {
                Error::Generation("beam-search cache capacity overflows usize".into())
            })?;
        if request.cache.capacity() < required_capacity {
            return Err(Error::Generation(format!(
                "beam-search cache capacity {} is smaller than required decoder prompt {maximum_prompt} + {} generated tokens = {required_capacity}",
                request.cache.capacity(),
                request.search.max_new_tokens
            )));
        }

        let initial_next_positions = request
            .decoder_prompt
            .position_ids
            .clone()
            .map(|positions| {
                tensor_i64_values(positions, "decoder prompt positions").and_then(|values| {
                    next_positions(
                        &values,
                        &decoder_valid,
                        decoder_batch,
                        decoder_sequence,
                        request.search.max_new_tokens,
                    )
                })
            })
            .transpose()?;
        Ok(Self {
            source_batch,
            expanded_batch,
            decoder_prompt_lengths,
            has_explicit_decoder_positions: initial_next_positions.is_some(),
            initial_next_positions,
        })
    }
}

/// Internal unfinished or finalized hypothesis.
#[derive(Clone, Debug)]
struct BeamHypothesis {
    token_ids: Vec<u32>,
    log_probabilities: Vec<f64>,
    cumulative_log_probability: f64,
    next_position: Option<i64>,
    finish_reason: Option<FinishReason>,
    ordinal: usize,
}

/// One not-yet-materialized child from a model probability row.
#[derive(Clone, Copy, Debug)]
struct Candidate {
    parent_global: usize,
    parent_slot: usize,
    token_id: u32,
    log_probability: f64,
    cumulative_log_probability: f64,
}

/// Creates one score-zero live prefix per source and dormant spare slots.
fn initial_beams(prepared: &PreparedRequest) -> Result<Vec<Option<BeamHypothesis>>> {
    let beams_per_source = prepared.expanded_batch / prepared.source_batch;
    let mut active = vec![None; prepared.expanded_batch];
    for source in 0..prepared.source_batch {
        let row = source
            .checked_mul(beams_per_source)
            .ok_or_else(|| Error::Generation("initial beam index overflow".into()))?;
        active[row] = Some(BeamHypothesis {
            token_ids: Vec::new(),
            log_probabilities: Vec::new(),
            cumulative_log_probability: 0.0,
            next_position: prepared
                .initial_next_positions
                .as_ref()
                .and_then(|positions| positions.get(source).copied()),
            finish_reason: None,
            ordinal: source,
        });
    }
    Ok(active)
}

/// Allocates one empty finished-hypothesis pool per source row.
fn empty_completed(batch: usize) -> Result<Vec<Vec<BeamHypothesis>>> {
    let mut completed = Vec::new();
    completed.try_reserve_exact(batch).map_err(|_| {
        Error::Generation(format!(
            "failed to allocate completed beam pools for batch size {batch}"
        ))
    })?;
    completed.resize_with(batch, Vec::new);
    Ok(completed)
}

/// Enumerates and stably ranks every finite beam-vocabulary continuation.
fn candidates_for_source(
    source: usize,
    beams: usize,
    vocabulary: usize,
    active: &[Option<BeamHypothesis>],
    probabilities: &[f64],
) -> Result<Vec<Candidate>> {
    let start = source
        .checked_mul(beams)
        .ok_or_else(|| Error::Generation("beam source offset overflow".into()))?;
    let mut candidates = Vec::new();
    for parent_slot in 0..beams {
        let parent_global = start
            .checked_add(parent_slot)
            .ok_or_else(|| Error::Generation("beam parent index overflow".into()))?;
        let Some(parent) = active.get(parent_global).and_then(Option::as_ref) else {
            continue;
        };
        let probability_offset = parent_global
            .checked_mul(vocabulary)
            .ok_or_else(|| Error::Generation("beam probability offset overflow".into()))?;
        let probability_end = probability_offset
            .checked_add(vocabulary)
            .ok_or_else(|| Error::Generation("beam probability row end overflow".into()))?;
        let row = probabilities
            .get(probability_offset..probability_end)
            .ok_or_else(|| Error::Generation("beam probability matrix became ragged".into()))?;
        candidates.try_reserve(vocabulary).map_err(|_| {
            Error::Generation(format!("failed to allocate {vocabulary} beam candidates"))
        })?;
        for (token, &log_probability) in row.iter().enumerate() {
            if log_probability == f64::NEG_INFINITY {
                continue;
            }
            if !log_probability.is_finite() {
                return Err(Error::Generation(format!(
                    "beam {parent_global} token {token} produced non-finite log probability {log_probability}"
                )));
            }
            let token_id = u32::try_from(token).map_err(|_| {
                Error::Generation(format!(
                    "vocabulary token {token} exceeds the u32 token-ID domain"
                ))
            })?;
            let cumulative_log_probability = parent.cumulative_log_probability + log_probability;
            if !cumulative_log_probability.is_finite() {
                return Err(Error::Generation(format!(
                    "beam {parent_global} token {token} overflowed cumulative log probability"
                )));
            }
            candidates.push(Candidate {
                parent_global,
                parent_slot,
                token_id,
                log_probability,
                cumulative_log_probability,
            });
        }
    }
    candidates.sort_by(candidate_order);
    Ok(candidates)
}

/// Defines deterministic candidate order independently of backend sort rules.
fn candidate_order(left: &Candidate, right: &Candidate) -> core::cmp::Ordering {
    right
        .cumulative_log_probability
        .total_cmp(&left.cumulative_log_probability)
        .then_with(|| left.parent_slot.cmp(&right.parent_slot))
        .then_with(|| left.token_id.cmp(&right.token_id))
}

/// Sizes the conventional top frontier examined for EOS and live prefixes.
///
/// One beam width supplies live children and each distinct EOS ID can consume
/// another width. A minimum factor of two matches ordinary single-EOS search.
fn candidate_frontier_size(beams: usize, eos_count: usize, available: usize) -> Result<usize> {
    let multiplier = eos_count
        .checked_add(1)
        .ok_or_else(|| Error::Generation("beam-search EOS count overflows usize".into()))?
        .max(2);
    beams
        .checked_mul(multiplier)
        .map(|frontier| frontier.min(available))
        .ok_or_else(|| Error::Generation("beam-search candidate frontier overflows usize".into()))
}

/// Materializes a candidate by extending its parent's token and score vectors.
fn extend_candidate(
    active: &[Option<BeamHypothesis>],
    candidate: &Candidate,
    finish_reason: Option<FinishReason>,
    ordinal: usize,
) -> Result<BeamHypothesis> {
    let parent = active
        .get(candidate.parent_global)
        .and_then(Option::as_ref)
        .ok_or_else(|| Error::Generation("beam candidate parent is unavailable".into()))?;
    let mut token_ids = parent.token_ids.clone();
    token_ids
        .try_reserve(1)
        .map_err(|_| Error::Generation("failed to extend beam token history".into()))?;
    token_ids.push(candidate.token_id);
    let mut log_probabilities = parent.log_probabilities.clone();
    log_probabilities
        .try_reserve(1)
        .map_err(|_| Error::Generation("failed to extend beam probability history".into()))?;
    log_probabilities.push(candidate.log_probability);
    let next_position = parent
        .next_position
        .map(|position| {
            position
                .checked_add(1)
                .ok_or_else(|| Error::Generation("explicit decoder position overflow".into()))
        })
        .transpose()?;
    Ok(BeamHypothesis {
        token_ids,
        log_probabilities,
        cumulative_log_probability: candidate.cumulative_log_probability,
        next_position,
        finish_reason,
        ordinal,
    })
}

/// Sorts finished hypotheses by public score and retains only the beam width.
fn rank_and_prune(hypotheses: &mut Vec<BeamHypothesis>, beams: usize, length_penalty: f64) {
    hypotheses.sort_by(|left, right| completed_order(left, right, length_penalty));
    hypotheses.truncate(beams);
}

/// Compares finished hypotheses using documented deterministic tie breakers.
fn completed_order(
    left: &BeamHypothesis,
    right: &BeamHypothesis,
    length_penalty: f64,
) -> core::cmp::Ordering {
    normalized_score(right, length_penalty)
        .total_cmp(&normalized_score(left, length_penalty))
        .then_with(|| {
            right
                .cumulative_log_probability
                .total_cmp(&left.cumulative_log_probability)
        })
        .then_with(|| left.token_ids.cmp(&right.token_ids))
        .then_with(|| left.ordinal.cmp(&right.ordinal))
}

/// Computes a length-normalized score, checked for overflow before public output.
fn normalized_score(hypothesis: &BeamHypothesis, length_penalty: f64) -> f64 {
    hypothesis.cumulative_log_probability / (hypothesis.token_ids.len() as f64).powf(length_penalty)
}

/// Converts internal finished pools into stable public output.
///
/// A finite cumulative log probability divided by a positive subnormal length
/// normalizer can still overflow F64. Such scores are rejected contextually,
/// without changing the requested penalty or clamping the mathematical result.
fn finish_output(
    mut completed: Vec<Vec<BeamHypothesis>>,
    prompt_lengths: &[usize],
    search: &BeamSearchConfig,
) -> Result<Seq2SeqBeamSearchOutput> {
    if completed.len() != prompt_lengths.len() {
        return Err(Error::Generation(
            "beam-search result batch does not match decoder prompt batch".into(),
        ));
    }
    let mut sequences = Vec::new();
    sequences
        .try_reserve_exact(completed.len())
        .map_err(|_| Error::Generation("failed to allocate beam-search output batch".into()))?;
    for (source, hypotheses) in completed.iter_mut().enumerate() {
        rank_and_prune(hypotheses, search.num_beams, search.length_penalty);
        if hypotheses.len() < search.num_return_sequences {
            return Err(Error::Generation(format!(
                "beam-search source row {source} produced {} finished hypotheses, fewer than requested {}",
                hypotheses.len(),
                search.num_return_sequences
            )));
        }
        let prompt_length = *prompt_lengths
            .get(source)
            .ok_or_else(|| Error::Generation("decoder prompt lengths became ragged".into()))?;
        let mut returned = Vec::new();
        returned
            .try_reserve_exact(search.num_return_sequences)
            .map_err(|_| Error::Generation("failed to allocate returned beam hypotheses".into()))?;
        for hypothesis in hypotheses.drain(..search.num_return_sequences) {
            let score = normalized_score(&hypothesis, search.length_penalty);
            if !score.is_finite() {
                return Err(Error::Generation(format!(
                    "beam-search source row {source} produced a non-finite normalized score for {} generated tokens",
                    hypothesis.token_ids.len(),
                )));
            }
            let finish_reason = hypothesis.finish_reason.ok_or_else(|| {
                Error::Generation("unfinished hypothesis reached beam output".into())
            })?;
            returned.push(BeamSearchSequence {
                decoder_prompt_length: prompt_length,
                token_ids: hypothesis.token_ids,
                log_probabilities: hypothesis.log_probabilities,
                cumulative_log_probability: hypothesis.cumulative_log_probability,
                score,
                finish_reason,
            });
        }
        sequences.push(returned);
    }
    Ok(Seq2SeqBeamSearchOutput { sequences })
}

/// Applies a batch gather to every tensor carried by an encoder output.
fn select_encoder<B: Backend>(
    encoder: EncoderOutput<B>,
    indices: &[usize],
) -> Result<EncoderOutput<B>> {
    let selector = batch_selector::<B>(indices, &encoder.hidden_state.device())?;
    Ok(EncoderOutput {
        hidden_state: encoder.hidden_state.select(0, selector.clone()),
        token_mask: encoder.token_mask.map(|mask| {
            TokenMask::new(select_bool_tensor(mask.into_tensor(), 0, selector.clone()))
        }),
        hidden_states: encoder
            .hidden_states
            .into_iter()
            .map(|hidden| hidden.select(0, selector.clone()))
            .collect(),
        attentions: encoder
            .attentions
            .into_iter()
            .map(|attention| attention.select(0, selector.clone()))
            .collect(),
    })
}

/// Applies a batch gather to a token input and all optional metadata.
fn select_input<B: Backend>(
    input: CausalLmInput<B>,
    indices: &[usize],
) -> Result<CausalLmInput<B>> {
    let selector = batch_selector::<B>(indices, &input.token_ids.device())?;
    Ok(CausalLmInput {
        token_ids: input.token_ids.select(0, selector.clone()),
        token_mask: input.token_mask.map(|mask| {
            TokenMask::new(select_bool_tensor(mask.into_tensor(), 0, selector.clone()))
        }),
        position_ids: input
            .position_ids
            .map(|positions| positions.select(0, selector)),
    })
}

/// Builds the initial repeated source-row selector in group-major order.
fn beam_expansion_indices(batch: usize, beams: usize) -> Result<Vec<usize>> {
    let count = batch
        .checked_mul(beams)
        .ok_or_else(|| Error::Generation("beam expansion count overflows usize".into()))?;
    let mut indices = Vec::new();
    indices.try_reserve_exact(count).map_err(|_| {
        Error::Generation(format!("failed to allocate {count} beam expansion indices"))
    })?;
    for source in 0..batch {
        indices.extend(std::iter::repeat_n(source, beams));
    }
    Ok(indices)
}

/// Converts host indices to Burn's portable signed batch selector.
fn batch_selector<B: Backend>(indices: &[usize], device: &B::Device) -> Result<Tensor<B, 1, Int>> {
    let values = indices
        .iter()
        .map(|&index| {
            i64::try_from(index).map_err(|_| {
                Error::Generation(format!(
                    "beam batch index {index} exceeds the signed tensor-index domain"
                ))
            })
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(Tensor::from_data(
        TensorData::new(values, [indices.len()]),
        device,
    ))
}

/// Validates optional mask and position rectangles before model execution.
fn validate_input_metadata<B: Backend>(
    input: &CausalLmInput<B>,
    batch: usize,
    sequence: usize,
    label: &str,
) -> Result<()> {
    if let Some(mask) = &input.token_mask
        && mask.as_tensor().dims() != [batch, sequence]
    {
        return Err(Error::shape(
            format!("beam_search.{label}.token_mask"),
            format!("[{batch}, {sequence}]"),
            format!("{:?}", mask.as_tensor().dims()),
        ));
    }
    if let Some(positions) = &input.position_ids
        && positions.dims() != [batch, sequence]
    {
        return Err(Error::shape(
            format!("beam_search.{label}.position_ids"),
            format!("[{batch}, {sequence}]"),
            format!("{:?}", positions.dims()),
        ));
    }
    Ok(())
}

/// Verifies model-produced encoder batch geometry.
fn validate_encoder_batch<B: Backend>(encoder: &EncoderOutput<B>, batch: usize) -> Result<()> {
    let [observed_batch, source, hidden] = encoder.hidden_state.dims();
    if observed_batch != batch || source == 0 || hidden == 0 {
        return Err(Error::shape(
            "beam_search.encoder_output",
            format!("[{batch}, nonzero_source, nonzero_hidden]"),
            format!("{:?}", encoder.hidden_state.dims()),
        ));
    }
    if let Some(mask) = &encoder.token_mask
        && mask.as_tensor().dims() != [batch, source]
    {
        return Err(Error::shape(
            "beam_search.encoder_output.token_mask",
            format!("[{batch}, {source}]"),
            format!("{:?}", mask.as_tensor().dims()),
        ));
    }
    for (index, state) in encoder.hidden_states.iter().enumerate() {
        if state.dims() != [batch, source, hidden] {
            return Err(Error::shape(
                format!("beam_search.encoder_output.hidden_states[{index}]"),
                format!("[{batch}, {source}, {hidden}]"),
                format!("{:?}", state.dims()),
            ));
        }
    }
    for (index, attention) in encoder.attentions.iter().enumerate() {
        let [attention_batch, heads, query, key] = attention.dims();
        if attention_batch != batch || heads == 0 || query != source || key != source {
            return Err(Error::shape(
                format!("beam_search.encoder_output.attentions[{index}]"),
                format!("[{batch}, nonzero_heads, {source}, {source}]"),
                format!("{:?}", attention.dims()),
            ));
        }
    }
    Ok(())
}

/// Extracts `[beam_batch, vocabulary]` scores from last-logit model output.
fn extract_last_logits<B: Backend>(
    logits: Tensor<B, 3>,
    batch: usize,
    vocabulary: usize,
) -> Result<Tensor<B, 2>> {
    if logits.dims() != [batch, 1, vocabulary] {
        return Err(Error::shape(
            "beam_search.model_logits",
            format!("[{batch}, 1, {vocabulary}]"),
            format!("{:?}", logits.dims()),
        ));
    }
    Ok(logits.squeeze_dim::<2>(1))
}

/// Computes row-wise log-softmax and transfers the existing beam candidate matrix.
///
/// Host decoding follows the tensor's runtime float dtype, preserving F64 values
/// and accepting F16/BF16 results from backends whose default element type is F32.
fn host_log_probabilities<B: Backend>(
    logits: Tensor<B, 2>,
    active: &[bool],
    batch: usize,
    vocabulary: usize,
) -> Result<Vec<f64>> {
    if logits.dims() != [batch, vocabulary] || active.len() != batch {
        return Err(Error::Generation(
            "beam-search active metadata does not match model logits".into(),
        ));
    }
    let device = logits.device();
    let active_mask =
        bool_tensor_from_values(active.to_vec(), [batch, 1], &device).expand([batch, vocabulary]);
    let data = log_softmax(logits.mask_fill(active_mask.bool_not(), 0.0), 1)
        .try_into_data()
        .map_err(|error| {
            Error::BackendCapability(format!(
                "failed to read beam-search log probabilities from backend: {error}"
            ))
        })?;
    host_float_data_f64(data, "beam-search log probabilities")
}

/// Materializes a token mask or an all-valid rectangle on the host.
fn mask_values<B: Backend>(
    mask: Option<&TokenMask<B>>,
    batch: usize,
    sequence: usize,
    label: &str,
) -> Result<Vec<bool>> {
    match mask {
        Some(mask) => mask
            .as_tensor()
            .clone()
            .int()
            .try_into_data()
            .map_err(|error| Error::BackendCapability(format!("failed to read {label}: {error}")))?
            .to_vec::<B::IntElem>()
            .map(|values| {
                values
                    .into_iter()
                    .map(|value| value.elem::<i64>() != 0)
                    .collect()
            })
            .map_err(|error| Error::BackendCapability(format!("failed to read {label}: {error}"))),
        None => batch
            .checked_mul(sequence)
            .map(|count| vec![true; count])
            .ok_or_else(|| Error::Generation(format!("{label} size overflows usize"))),
    }
}

/// Counts valid entries and rejects fully masked prompt rows.
fn nonempty_row_lengths(
    valid: &[bool],
    batch: usize,
    sequence: usize,
    label: &str,
) -> Result<Vec<usize>> {
    let expected = batch
        .checked_mul(sequence)
        .ok_or_else(|| Error::Generation(format!("{label} size overflows usize")))?;
    if valid.len() != expected {
        return Err(Error::Generation(format!(
            "{label} mask contains {} entries, expected {expected}",
            valid.len()
        )));
    }
    let mut lengths = Vec::with_capacity(batch);
    for (row, values) in valid.chunks_exact(sequence).enumerate() {
        let length = values.iter().filter(|&&value| value).count();
        if length == 0 {
            return Err(Error::Generation(format!(
                "{label} row {row} has no valid tokens"
            )));
        }
        lengths.push(length);
    }
    Ok(lengths)
}

/// Finds the next explicit decoder position and preflights signed overflow.
fn next_positions(
    positions: &[i64],
    valid: &[bool],
    batch: usize,
    sequence: usize,
    max_new_tokens: usize,
) -> Result<Vec<i64>> {
    let expected = batch
        .checked_mul(sequence)
        .ok_or_else(|| Error::Generation("decoder position size overflows usize".into()))?;
    if positions.len() != expected || valid.len() != expected {
        return Err(Error::Generation(
            "decoder positions and token mask are not rectangular".into(),
        ));
    }
    let additional = i64::try_from(max_new_tokens).map_err(|_| {
        Error::Generation("beam-search length exceeds signed position domain".into())
    })?;
    let mut next = Vec::with_capacity(batch);
    for row in 0..batch {
        let offset = row
            .checked_mul(sequence)
            .ok_or_else(|| Error::Generation("decoder position offset overflow".into()))?;
        let end = offset
            .checked_add(sequence)
            .ok_or_else(|| Error::Generation("decoder position row end overflow".into()))?;
        let row_positions = positions
            .get(offset..end)
            .ok_or_else(|| Error::Generation("decoder position rows became ragged".into()))?;
        let row_valid = valid
            .get(offset..end)
            .ok_or_else(|| Error::Generation("decoder mask rows became ragged".into()))?;
        let last = row_positions
            .iter()
            .zip(row_valid)
            .rev()
            .find_map(|(&position, &is_valid)| is_valid.then_some(position))
            .ok_or_else(|| Error::Generation(format!("decoder prompt row {row} is empty")))?;
        if last < 0 {
            return Err(Error::Generation(format!(
                "decoder prompt row {row} has negative last position {last}"
            )));
        }
        let maximum = last.checked_add(additional).ok_or_else(|| {
            Error::Generation(format!("decoder prompt row {row} position overflow"))
        })?;
        if maximum > i64::from(i32::MAX) {
            return Err(Error::Generation(format!(
                "decoder prompt row {row} position {maximum} exceeds Burn's portable signed index range"
            )));
        }
        next.push(last + 1);
    }
    Ok(next)
}

/// Copies an integer tensor into portable host values with context.
fn tensor_i64_values<B: Backend, const D: usize>(
    tensor: Tensor<B, D, Int>,
    label: &str,
) -> Result<Vec<i64>> {
    tensor
        .try_into_data()
        .map_err(|error| Error::BackendCapability(format!("failed to read {label}: {error}")))?
        .to_vec::<B::IntElem>()
        .map(|values| {
            values
                .into_iter()
                .map(|value| value.elem::<i64>())
                .collect()
        })
        .map_err(|error| Error::BackendCapability(format!("failed to read {label}: {error}")))
}

#[cfg(test)]
#[path = "seq2seq_tests.rs"]
mod tests;
